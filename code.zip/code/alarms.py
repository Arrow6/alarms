import time
import random
import threading
import datetime
import tkinter as tk


filepath = "C:/Users/OneOneNot/PROJECTS/startup/alarms.alrm"
default = "C:/Users/OneOneNot/PROJECTS/startup/alarms.alrm"


class reminder(threading.Thread):
    def main(self):
        time.sleep(self.tms)
        self.fun()

    def init(self, fun, tms):
        self.fun = fun
        self.tms = tms

    def run(self):
        self.main()


entrys = []




def genentrynumber():
    return hex(random.randint(0, 65535))


def generatenumber():

    load()
    def gen():
        gen = genentrynumber()
        print(gen)
        number = gen[2:]
        print(number)
        start = ""
        for i in range(10 - len(number)):
            start += '0'
            print(start)
        num = start + number
        return num
    num = gen()
    
    


txt = None

def load():

    global txt

    with open(filepath, 'r') as f:
        txt = f.read()


def show():
    
    load()
    print(txt)


def add():
    
    text = input("add text: ")

    load()
    with open(filepath, 'w') as f:
        f.write(txt + '\n' + text)


def edit():
    pass


def clear():

    with open(filepath, 'w') as f:
        f.write("@start")


def remove(entry):
    pass


def setalarm():
    
    alarm = datetime.datetime(int(input("Enter the year: ")), int(input("Enter the month: ")), int(input("Enter the day: ")), int(input("Enter the hour: ")), int(input("Enter the minutes: ")), 0, 0)

    today = datetime.datetime.now()

    delta = alarm - today

    tms = delta.total_seconds()

    def wait():
        root = tk.Tk()
        root.geometry("250x0")
        root.title("The time is up")
        root.lift()
        root.attributes('-topmost',True)
        root.after_idle(root.attributes,'-topmost',False)
        root.mainloop()

    timer = reminder()
    timer.init(wait, tms)
    timer.start()


def loadfile():

    global filepath

    filepath = input("Enter the new file path :)")
    load()
    

def debug():
    
    command = input("enter debug code: ")
    c = compile(command, "debugcode", "exec")
    exec(c)


def help():
    print("type -show for vewing you schedule")
    print("type -add to add something in your schedule")
    print("type -exit to close the programm")
    print("type -reminder to add a reminder")
    print("type -clear to clear your schedule")


def main():
    
    help()

    while True:
        
        c = input("--> ")
        
        if c == "show":

            show()
        
        elif c == "add":
            
            add()
        
        elif c == "edit":
            
            print("Not supported yet :() \n But don't worry we are working on it right now!")
        
        elif c == "exit":
            
            print("Goodbye :(")
            time.sleep(2)
            break
        
        elif c == "clear":
            
            sure = input("Are you sure (YES/NO)")
            if sure == "YES":
                clear()
            else:
                print("Ok canceled :)")

        elif c == "reminder":

            setalarm()
        
        elif c == "deb":

            debug()

        elif c == "help":
            
            help()

        else:
            
            print("Unknow command :( type -help for help :)")
            continue


main()